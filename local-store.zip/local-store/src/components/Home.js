import { useEffect, useState } from "react"
import { useNavigate } from "react-router-dom"


function Home() {
    const navigate = useNavigate()
    const [desc,setDesc] = useState([])
    const [blogs, setBlogs] = useState([])

    useEffect(() => {
        const blogs = localStorage.getItem('blogs')
        setBlogs(JSON.parse(blogs))
    }, [blogs])


    const handleView =(blogIndex)=> {
        
        localStorage.setItem('ViewIndex', blogIndex)

        // // console.log({ title, desc, index: localStorage.getItem('ViewIndex') })
        // let blogs = localStorage.getItem('blogs') && localStorage.getItem('blogs').length > 0 ? JSON.parse(localStorage.getItem('blogs')) : []

     
        // blogs.map((blog,blogIndex) => {
        //     if (blogIndex == localStorage.getItem('ViewIndex')) {
        //         return { blog?.desc}
        //     } 
        // })
        // // console.log(_blogs)?\
        
        navigate('/Description')

    }   

   
    return (
        <div style={{textAlign:'center'}}>
            <br />
            
            <button  type="button" class="btn btn-primary" style={{}}
                onClick={() => {navigate('/add')}}
                variant="contained" > ADD BLOG </button>
            <br />

            {
                blogs && blogs.length > 0 ?
                    blogs.map((blog,blogIndex) => {
                        return (
                            <div style={{ borderBottom: "1px solid #eee", margin: '10px 0px' }}>
                                <button style={{width: '500px',height:'60px'}}  onClick={() => handleView(blogIndex)}>
                                    {blog?.title} </button>
                               </div>
                        )
                    })
                    :
                    'No Data found'
            }
        </div>
    )
}

export default Home