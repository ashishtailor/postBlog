import React from 'react'

const Header = ()=> {
  return(
    <>
  <nav class="navbar navbar-expand-lg bg-dark m-2">
  <div class="container-fluid">
    <a class="navbar-brand text-white" href="/">BlogApp</a>
    
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      
      <form class="d-flex" role="search">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search" />
        <button class="btn btn-info " type="submit">Search</button>
      </form>
    </div>
  </div>
</nav>
    </>
  )
}

export default Header;