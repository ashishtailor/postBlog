
import { Button, TextField, Typography } from "@mui/material"
import { useState } from "react"
import { useNavigate } from "react-router-dom"



function Add() {
    const navigate = useNavigate()
    const [title, setTitle] = useState('')
    const [categories,setCategories] = useState('')
    const [desc, setDesc] = useState('')

    const handleTitleChange = (e) => {
        setTitle(e.target.value)
    }
    const handleCategoriesChange = (e) => {
        setCategories(e.target.value)
    }
    const handleDescChange = (e) => {
        setDesc(e.target.value)
    }


    const handleSubmit = () => {
        console.log({ title, desc })

        const _blogs = localStorage.getItem('blogs') && localStorage.getItem('blogs').length > 0 ? JSON.parse(localStorage.getItem('blogs')) : []

        localStorage.setItem('blogs', JSON.stringify([..._blogs, { title, categories,desc }]))

        navigate('/')
    }

    return (<>
 
        <button type='button' class='btn btn-primary' onClick={() => {navigate('/')}}>Back</button>
        <div style={{textAlign:'center'}}>
            <label style={{margin:10}}> ADD BLOG </label>

            <div class="input-group mb-3" style={{height: '50px', width:'50%',marginLeft:'25%'}}>
                
            <input type="text" class="form-control" value={title} onChange={(e) => handleTitleChange(e)} placeholder="Title"  />
            </div>

            <div class="input-group mb-3" style={{height: '50px', width:'50%',marginLeft:'25%'}}>
            <input type="text" class="form-control" value={categories} onChange={(e) => handleCategoriesChange(e)} placeholder="Categories"  />
            </div>
            

            <div class="input-group mb-3" style={{height: '50px', width:'50%',marginLeft:'25%'}}>
            <textarea type="text" class="form-control" value={desc} onChange={(e) => handleDescChange(e)} placeholder="Description" rows={4}/>
            </div>
            <button onClick={handleSubmit}  type="button" class="btn btn-primary m-5 " > Submit </button>
        </div>
        </>
    )
}

export default Add